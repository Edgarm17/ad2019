//
//import org.xml.sax.InputSource;
//import org.xml.sax.XMLReader;
//import org.xml.sax.helpers.XMLReaderFactory;
//
//       
//// Creamos la factoria de analizadores por defecto  
//XMLReader reader = XMLReaderFactory.createXMLReader();
//// Creamos un objeto de nuestra GestionEventos
//GestionEventos gestor = new GestionEventos(...);
//// Añadimos nuestro manejador al reader pasandole el objeto leido  
//reader.setContentHandler(...);
//// Procesamos el xml de ejemplo  
//reader.parse(...);
